﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btncalcular_Click(object sender, EventArgs e)
        {
            int n1 = int.Parse(txt1.Text);
            int n2 = int.Parse(txt2.Text);
            string mensaje = "El resultado de: ";

            if (chbsuma.Checked==true)
            {
                int suma = n1 + n2;
                mensaje += "\nsuma: " + suma;
            }
            if (chbresta.Checked==true) 
            {
                int resta = n1 - n2;
                mensaje += "\nresta: " + resta;
            }
            if (chbmulti.Checked==true)
            {
                int multi = n1 * n2;
                mensaje += "\nmultiplicacion: " + multi;
            }
            if (chbmulti.Checked == false && chbresta.Checked == false && chbsuma.Checked == false)
            {
                MessageBox.Show("no has seleccionado ninguna opcion");
                mensaje = "no has seleccionado opcion ";
            }
            lblresultado.Text = mensaje;
        }
    }
}
