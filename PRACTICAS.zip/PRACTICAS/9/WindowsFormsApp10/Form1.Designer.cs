﻿namespace WindowsFormsApp10
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt1 = new System.Windows.Forms.TextBox();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.chbsuma = new System.Windows.Forms.CheckBox();
            this.chbresta = new System.Windows.Forms.CheckBox();
            this.chbmulti = new System.Windows.Forms.CheckBox();
            this.btncalcular = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblresultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(271, 41);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(100, 20);
            this.txt1.TabIndex = 0;
            // 
            // txt2
            // 
            this.txt2.Location = new System.Drawing.Point(271, 78);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(100, 20);
            this.txt2.TabIndex = 1;
            // 
            // chbsuma
            // 
            this.chbsuma.AutoSize = true;
            this.chbsuma.Location = new System.Drawing.Point(106, 41);
            this.chbsuma.Name = "chbsuma";
            this.chbsuma.Size = new System.Drawing.Size(53, 17);
            this.chbsuma.TabIndex = 2;
            this.chbsuma.Text = "Suma";
            this.chbsuma.UseVisualStyleBackColor = true;
            // 
            // chbresta
            // 
            this.chbresta.AutoSize = true;
            this.chbresta.Location = new System.Drawing.Point(106, 64);
            this.chbresta.Name = "chbresta";
            this.chbresta.Size = new System.Drawing.Size(57, 17);
            this.chbresta.TabIndex = 3;
            this.chbresta.Text = "Resta ";
            this.chbresta.UseVisualStyleBackColor = true;
            // 
            // chbmulti
            // 
            this.chbmulti.AutoSize = true;
            this.chbmulti.Location = new System.Drawing.Point(106, 87);
            this.chbmulti.Name = "chbmulti";
            this.chbmulti.Size = new System.Drawing.Size(93, 17);
            this.chbmulti.TabIndex = 4;
            this.chbmulti.Text = "Multiplicacion ";
            this.chbmulti.UseVisualStyleBackColor = true;
            // 
            // btncalcular
            // 
            this.btncalcular.Location = new System.Drawing.Point(494, 41);
            this.btncalcular.Name = "btncalcular";
            this.btncalcular.Size = new System.Drawing.Size(75, 23);
            this.btncalcular.TabIndex = 5;
            this.btncalcular.Text = "Calcular";
            this.btncalcular.UseVisualStyleBackColor = true;
            this.btncalcular.Click += new System.EventHandler(this.btncalcular_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(106, 144);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Resultado:";
            // 
            // lblresultado
            // 
            this.lblresultado.AutoSize = true;
            this.lblresultado.Location = new System.Drawing.Point(184, 144);
            this.lblresultado.Name = "lblresultado";
            this.lblresultado.Size = new System.Drawing.Size(22, 13);
            this.lblresultado.TabIndex = 7;
            this.lblresultado.Text = ".....";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblresultado);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btncalcular);
            this.Controls.Add(this.chbmulti);
            this.Controls.Add(this.chbresta);
            this.Controls.Add(this.chbsuma);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.txt1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.CheckBox chbsuma;
        private System.Windows.Forms.CheckBox chbresta;
        private System.Windows.Forms.CheckBox chbmulti;
        private System.Windows.Forms.Button btncalcular;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblresultado;
    }
}

