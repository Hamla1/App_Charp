﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2
{
    public partial class Form1 : Form
    {
        private int suma = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //private int suma = 0;
            int numero;
            //int suma = 0;
            //lbnumero.Items.Clears();
            numero =int.Parse(textBox1.Text);

            while (numero != 0)
            {
                lbnumero.Items.Add(numero);
                suma = suma + numero;
                //suma + numero;
                label3.Text = suma.ToString();
                textBox1.Clear();
                textBox1.Focus();
                break;
            }
            if (numero == 0)
            {
                textBox1.Enabled = false;
                lbnumero.Enabled = false;
                MessageBox.Show("Haz ingresado el numero 0, Aplicacion finalizada");
            }


        }
    }
}
