﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVer_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            if (checkDibujar.Checked==true)
            {
                listBox1.Items.Add("Dibujo");


            }
            if (checkCantar.Checked==true)
            {
                listBox1.Items.Add("Canto");
            }
            if (checkLeer.Checked==true)
            {
                listBox1.Items.Add("Leer");
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }
    }
}
