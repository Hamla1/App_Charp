﻿namespace _9
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkDibujar = new System.Windows.Forms.CheckBox();
            this.checkCantar = new System.Windows.Forms.CheckBox();
            this.checkLeer = new System.Windows.Forms.CheckBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.btnVer = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // checkDibujar
            // 
            this.checkDibujar.AutoSize = true;
            this.checkDibujar.Location = new System.Drawing.Point(61, 42);
            this.checkDibujar.Name = "checkDibujar";
            this.checkDibujar.Size = new System.Drawing.Size(59, 17);
            this.checkDibujar.TabIndex = 0;
            this.checkDibujar.Text = "Dibujar";
            this.checkDibujar.UseVisualStyleBackColor = true;
            // 
            // checkCantar
            // 
            this.checkCantar.AutoSize = true;
            this.checkCantar.Location = new System.Drawing.Point(61, 111);
            this.checkCantar.Name = "checkCantar";
            this.checkCantar.Size = new System.Drawing.Size(57, 17);
            this.checkCantar.TabIndex = 1;
            this.checkCantar.Text = "Cantar";
            this.checkCantar.UseVisualStyleBackColor = true;
            // 
            // checkLeer
            // 
            this.checkLeer.AutoSize = true;
            this.checkLeer.Location = new System.Drawing.Point(61, 174);
            this.checkLeer.Name = "checkLeer";
            this.checkLeer.Size = new System.Drawing.Size(47, 17);
            this.checkLeer.TabIndex = 2;
            this.checkLeer.Text = "Leer";
            this.checkLeer.UseVisualStyleBackColor = true;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(260, 73);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(120, 95);
            this.listBox1.TabIndex = 3;
            // 
            // btnVer
            // 
            this.btnVer.Location = new System.Drawing.Point(474, 73);
            this.btnVer.Name = "btnVer";
            this.btnVer.Size = new System.Drawing.Size(75, 23);
            this.btnVer.TabIndex = 4;
            this.btnVer.Text = "Ver";
            this.btnVer.UseVisualStyleBackColor = true;
            this.btnVer.Click += new System.EventHandler(this.btnVer_Click);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(474, 125);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpiar.TabIndex = 5;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.btnVer);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.checkLeer);
            this.Controls.Add(this.checkCantar);
            this.Controls.Add(this.checkDibujar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox checkDibujar;
        private System.Windows.Forms.CheckBox checkCantar;
        private System.Windows.Forms.CheckBox checkLeer;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button btnVer;
        private System.Windows.Forms.Button btnLimpiar;
    }
}

