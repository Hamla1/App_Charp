﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int[] numero = {10,20,30,40,50};

            int suma = 0;
            for (int i = 0; i < numero.Length; i++)
            {
                suma += numero[i];
            }
            for (int i = 0;i < numero.Length; i++)
            {
                listBox1.Items.Add(numero[i]);
            }
            double promedio = (double)suma / numero.Length;

            lbresultado.Text = promedio.ToString();
        }
    }
}
