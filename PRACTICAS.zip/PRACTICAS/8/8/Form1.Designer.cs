﻿namespace _8
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdbazul = new System.Windows.Forms.RadioButton();
            this.rdbamarillo = new System.Windows.Forms.RadioButton();
            this.rdbrojo = new System.Windows.Forms.RadioButton();
            this.btnVer = new System.Windows.Forms.Button();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.lblColor = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdbrojo);
            this.groupBox1.Controls.Add(this.rdbazul);
            this.groupBox1.Controls.Add(this.rdbamarillo);
            this.groupBox1.Location = new System.Drawing.Point(84, 47);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(480, 153);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // rdbazul
            // 
            this.rdbazul.AutoSize = true;
            this.rdbazul.Location = new System.Drawing.Point(33, 75);
            this.rdbazul.Name = "rdbazul";
            this.rdbazul.Size = new System.Drawing.Size(45, 17);
            this.rdbazul.TabIndex = 1;
            this.rdbazul.TabStop = true;
            this.rdbazul.Text = "Azul";
            this.rdbazul.UseVisualStyleBackColor = true;
            // 
            // rdbamarillo
            // 
            this.rdbamarillo.AutoSize = true;
            this.rdbamarillo.Location = new System.Drawing.Point(173, 75);
            this.rdbamarillo.Name = "rdbamarillo";
            this.rdbamarillo.Size = new System.Drawing.Size(61, 17);
            this.rdbamarillo.TabIndex = 2;
            this.rdbamarillo.TabStop = true;
            this.rdbamarillo.Text = "Amarillo";
            this.rdbamarillo.UseVisualStyleBackColor = true;
            // 
            // rdbrojo
            // 
            this.rdbrojo.AutoSize = true;
            this.rdbrojo.Location = new System.Drawing.Point(323, 75);
            this.rdbrojo.Name = "rdbrojo";
            this.rdbrojo.Size = new System.Drawing.Size(47, 17);
            this.rdbrojo.TabIndex = 3;
            this.rdbrojo.TabStop = true;
            this.rdbrojo.Text = "Rojo";
            this.rdbrojo.UseVisualStyleBackColor = true;
            // 
            // btnVer
            // 
            this.btnVer.Location = new System.Drawing.Point(625, 108);
            this.btnVer.Name = "btnVer";
            this.btnVer.Size = new System.Drawing.Size(75, 23);
            this.btnVer.TabIndex = 1;
            this.btnVer.Text = "Ver";
            this.btnVer.UseVisualStyleBackColor = true;
            this.btnVer.Click += new System.EventHandler(this.btnVer_Click);
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(625, 177);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(75, 23);
            this.btnLimpiar.TabIndex = 2;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // lblColor
            // 
            this.lblColor.AutoSize = true;
            this.lblColor.Location = new System.Drawing.Point(254, 238);
            this.lblColor.Name = "lblColor";
            this.lblColor.Size = new System.Drawing.Size(29, 13);
            this.lblColor.TabIndex = 3;
            this.lblColor.Text = "label";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(114, 238);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Color";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblColor);
            this.Controls.Add(this.btnLimpiar);
            this.Controls.Add(this.btnVer);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbrojo;
        private System.Windows.Forms.RadioButton rdbazul;
        private System.Windows.Forms.RadioButton rdbamarillo;
        private System.Windows.Forms.Button btnVer;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Label lblColor;
        private System.Windows.Forms.Label label1;
    }
}

