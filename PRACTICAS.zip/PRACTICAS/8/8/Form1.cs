﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVer_Click(object sender, EventArgs e)
        {
            if (rdbamarillo.Checked)
            {
                lblColor.Text = "Amarillo";
            }
            else if (rdbazul.Checked)
            {
                lblColor.Text = "Azul";
            } else if (rdbrojo.Checked)
            {
                lblColor.Text = "Rojo";
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            rdbazul.Checked = false;
            rdbrojo.Checked = false;
            rdbamarillo.Checked = false;
            lblColor.Text = "";
        }
    }
}
